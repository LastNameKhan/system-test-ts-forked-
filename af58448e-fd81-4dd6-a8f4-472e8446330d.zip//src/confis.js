export const baseURL = "https://dummyjson.com";
