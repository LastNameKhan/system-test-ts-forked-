import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import React, { useEffect, useState, useMemo } from "react";

const UserTable = ({ limitValue = 1000, skipValue = 0 }) => {
  const [users, setUsers] = useState([]);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const pageSize = 10;

  useEffect(() => {
    try {
      setLoading(true);
      fetch(`https://dummyjson.com/users?limit=${limitValue}&skip=${skipValue}`)
        .then((res) => res.json())
        .then((data) => setUsers(data.users));
      setLoading(false);
    } catch (e) {
      console.log("Error in getting the user Data:", e);
    }
  }, []);

  const filteredData = users.filter((user) =>
    `${user.firstName} ${user.lastName}`.toLowerCase().includes(query)
  );

  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize));
  const start = (page - 1) * pageSize;
  const pageItems = filteredData.slice(start, start + pageSize);

  useEffect(() => setPage(1), [query]);

  if (loading) return <p>Loading... </p>;

  return (
    <div>
      <TextField
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        type="text"
        placeholder="Please enter a value"
      />
      {filteredData.length === 0 ? (
        <p> No Users Found </p>
      ) : (
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell align="right" sx={{ fontWeight: "700" }}>
                  Name
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: "700" }}>
                  Email
                </TableCell>
                <TableCell align="right" sx={{ fontWeight: "700" }}>
                  Phone
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pageItems.map((user) => (
                <TableRow
                  key={user.id}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell component="th" scope="row">
                    {user.firstName} {user.lastName}
                  </TableCell>
                  <TableCell align="right">{user.email}</TableCell>
                  <TableCell align="right">{user.phone}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
        // <>
        //   <table>
        //     <thead>
        //       <th>Name </th>
        //       <th>Email </th>
        //       <th> Phone </th>
        //     </thead>
        //     <tbody>
        //       {pageItems.map((user) => (
        //         <tr key={user.id}>
        //           <td>
        //             {user.firstName} {user.lastName}
        //           </td>
        //           <td>{user.email}</td>
        //           <td>{user.phone}</td>
        //         </tr>
        //       ))}
        //     </tbody>
        //   </table>
        //   <div style={{ marginTop: 8 }}>
        //     <button
        //       onClick={() => setPage((prev) => Math.max(1, prev - 1))}
        //       disabled={page === 1}
        //     >
        //       Prev
        //     </button>
        //     <button
        //       onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
        //       disabled={page === totalPages}
        //     >
        //       Next
        //     </button>
        //   </div>
        // </>
      )}
    </div>
  );
};

export default UserTable;
